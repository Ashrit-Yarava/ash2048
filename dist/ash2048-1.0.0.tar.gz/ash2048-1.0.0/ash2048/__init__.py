from gym2048.env import Game2048
